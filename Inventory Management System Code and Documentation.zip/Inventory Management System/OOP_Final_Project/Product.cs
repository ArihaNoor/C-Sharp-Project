﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Final_Project
{
    class Product
    {
        public int ProdID { get; set; }
        public string ProdName { get; set; }
        public string ProdDesc { get; set; }
        public float ProdPrice { get; set; }
        public int CatID { get; set; }
        public string ProdUnit { get; set; }


        public static DataTable Display()
        {
            string sql = @"SELECT [ProductID]
      ,[ProdName]
      ,[ProdDesc]
      ,[ProdPrice]
      , b.catname, [ProdUnit]
   FROM[tblProduct] a, tblCategory b
  where a.catid = b.catid";
            DataTable dt = DB.getDatabyQuery(sql);
            return dt;

        }
    }
}

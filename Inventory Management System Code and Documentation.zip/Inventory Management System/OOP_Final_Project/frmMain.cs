﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP_Final_Project
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            User U = new User();
            U.Uname = txtUname.Text;
            U.UPassword = txtPwd.Text;
            GlobalVariables.loggedInuser = DB.AuthenticateUser(U.Uname, U.UPassword);
            if (GlobalVariables.loggedInuser.Uname == null)
            {
                MessageBox.Show("Invalid User Credential, please try again.");
                txtUname.Focus();
            }
            else
            {
                frmHome frm = new frmHome();
                this.Hide();
                frm.Show();

            }
        }

        private void pnlLogin_Paint(object sender, PaintEventArgs e)
        {

        }

        private void chkShow_CheckedChanged(object sender, EventArgs e)
        {
            if(chkShow.Checked == true)
            {
                txtPwd.isPassword = true;
            }
            else
            {
                txtPwd.isPassword = false;
            }
        }

        private void lblClear_Click(object sender, EventArgs e)
        {
            txtUname.Text = "";
            txtPwd.Text = "";
                 
        }

        private void frmMain_Load(object sender, EventArgs e)
        {

        }

        private void txtUname_MouseClick(object sender, MouseEventArgs e)
        {
            txtUname.Text = "";
            
        }

        private void txtPwd_MouseClick(object sender, MouseEventArgs e)
        {
            txtPwd.Text = "";
        }
    }
}

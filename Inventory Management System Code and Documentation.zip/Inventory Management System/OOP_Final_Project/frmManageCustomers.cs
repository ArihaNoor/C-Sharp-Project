﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP_Final_Project
{
    public partial class frmManageCustomers : Form
    {
        public frmManageCustomers()
        {
            InitializeComponent();
            dgvCust.DataSource = Customer.Display();
        }
        void ClearTB()
        {
            txtID.Text = " CUSTOMER ID";
            txtName.Text = "CUSTOMER NAME";
            txtPhone.Text = "PHONE NO.";
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            Customer Cust = new Customer();
            //Cust.CustID = int.Parse(txtID.Text);
            Cust.CustName = txtName.Text;
            Cust.CustPhone = txtPhone.Text;
            try
            {
                string sql = $"INSERT INTO tblCustomer(CustName,CustPhone) Values ('{Cust.CustName}','{Cust.CustPhone}')";
                DB.SaveData(sql);
                MessageBox.Show("Data Saved To Database");
                btnShow_Click(sender, e);
                ClearTB();
                
            }
            catch (Exception)
            {
                MessageBox.Show("Data Not Saved to Database");

            }

        }

        private void label9_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dgvCust.SelectedRows.Count > 0)
            {
                Customer Cust = new Customer();
                Cust.CustID = int.Parse(txtID.Text);
                Cust.CustName = txtName.Text;
                Cust.CustPhone = txtPhone.Text;

                try
                {
                    string sql = $@"UPDATE tblCustomer
                             SET 
                                 [CustName] = '{Cust.CustName}',
                                 [CustPhone] = '{Cust.CustPhone}'
                                where [CustID] = {Cust.CustID}
                             ";
                    DB.SaveData(sql);
                    MessageBox.Show("Data Updated in Database");
                    btnShow_Click(sender, e);
                    ClearTB();

                }
                catch (Exception)
                {
                    MessageBox.Show("Data Not Updated");
                    throw;

                }
            }
            else
            {
                MessageBox.Show("Select Rows to Update Data");
            }
           

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvCust.Rows.Count > 0)
            {
                Customer Cust = new Customer();
                Cust.CustID = int.Parse(txtID.Text);
                if(Cust.CustID == 0)
                {
                    MessageBox.Show("Select Rows to Delete Data");
                }
                else
                {
                    try
                    {
                        string sql = $@"Delete tblCustomer
                             where [CustID] = '{Cust.CustID}'
                             ";
                        DB.SaveData(sql);
                        MessageBox.Show("Data Deleted From Database");
                        btnShow_Click(sender, e);
                        ClearTB();

                    }
                    catch (Exception)
                    {
                        MessageBox.Show("Data Not Deleted");
                        throw;

                    }
                }
                
            }
            else
            {
                MessageBox.Show("Select Rows to Delete Data");
            }
            
        }

        private void btnShow_Click(object sender, EventArgs e)
        {

            dgvCust.DataSource = Customer.Display();
        }

        private void dgvCust_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (dgvCust.SelectedRows.Count > 0)
            {
                txtID.Text = dgvCust.SelectedRows[0].Cells[0].Value.ToString();
                txtName.Text = dgvCust.SelectedRows[0].Cells[1].Value.ToString();
                txtPhone.Text = dgvCust.SelectedRows[0].Cells[2].Value.ToString();
                
            }
        }

        private void frmManageCustomers_Load(object sender, EventArgs e)
        {

        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            frmHome frm = new frmHome();
            this.Hide();
            frm.Show();
        }

        private void dgvCust_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

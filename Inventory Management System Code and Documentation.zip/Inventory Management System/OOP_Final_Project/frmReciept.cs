﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP_Final_Project
{
    public partial class frmReciept : Form
    {
        public frmReciept()
        {
            InitializeComponent();
        }

        frmTransactionIN frm = new frmTransactionIN();
        private void label11_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void frmReciept_Load(object sender, EventArgs e)
        {
            string sql = $@"Select a.BillID,ProductID,ProductName,UnitPrice,Unit,a.TotalPrice,c.Sname
                            From tblSRecieptDetail a, tblSReciept b,tblSupplier c
                            Where a.BillID = b.BillID AND b.SID = c.SID AND a.BillID = {GlobalVariables.GBillID}";
            DataTable dt = DB.getDatabyQuery(sql);
            txtBillID.Text = dt.Rows[0]["BillID"].ToString();
            txtCustName.Text = dt.Rows[0]["Sname"].ToString();
            txtTotalBill.Text = dt.Rows[0]["TotalPrice"].ToString();
            dgvBill.DataSource = dt;
        }

        private void txtCustName_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

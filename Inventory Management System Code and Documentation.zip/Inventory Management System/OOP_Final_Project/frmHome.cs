﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP_Final_Project
{
    public partial class frmHome : Form
    {
        public frmHome()
        {
            InitializeComponent();
        }

        private void LoadControls()
        {
            var usr = GlobalVariables.loggedInuser;

            lblRole.Text = $" Logged in user Name: {usr.UfullName}  with role :  {usr.Role}  on :{DateTime.Now.ToShortTimeString()}";

            if (usr.Role == ("Store Keeper"))
            {
                lblCustomer.Visible = true;
                lblOut.Visible = true;
                lblIN.Visible = true;
                lblProduct.Visible = false;
                lblCategory.Visible = false;
                lblSupplier.Visible = false;
                lblUser.Visible = false;

            }
            else if(usr.Role == ("Stock Manager"))
            {
                lblProduct.Visible = true;
                lblIN.Visible = true;
                lblOut.Visible = true;
                lblCategory.Visible = true;
                lblCustomer.Visible = true;
                lblSupplier.Visible = true;
                lblUser.Visible = false;

            }
            else if (usr.Role == ("Admin"))
            {
                lblProduct.Visible = true;
                lblIN.Visible = true;
                lblOut.Visible = true;
                lblCategory.Visible = true;
                lblCustomer.Visible = true;
                lblSupplier.Visible = true;
                lblUser.Visible = true;

            }
            else if (usr.Role == ("Sales Manager"))
            {
                lblProduct.Visible = true;
                lblIN.Visible = true;
                lblOut.Visible = true;
                lblCategory.Visible = true;
                lblCustomer.Visible = true;
                lblSupplier.Visible = true;
                lblUser.Visible = false;

            }
            else
            {
                lblProduct.Visible = false;
                lblIN.Visible = false;
                lblOut.Visible = false;
                lblCategory.Visible = false;
                lblCustomer.Visible = false;
                lblSupplier.Visible = false;
                lblUser.Visible = false;
            }

        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {

            Application.Exit();
        }

        private void lblRole_Click(object sender, EventArgs e)
        {

        }

        private void frmHome_Load(object sender, EventArgs e)
        {
            LoadControls();
        }

        private void lblCustomer_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmManageCustomers frm = new frmManageCustomers();
            this.Hide();
            frm.Show();

        }

        private void lblProduct_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmManageProducts frm = new frmManageProducts();
            this.Hide();
            frm.Show();
        }

        private void lblOut_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmTransactionOUT frm = new frmTransactionOUT();
            this.Hide();
            frm.Show();
        }

        private void lblUser_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmManagerUsers frm = new frmManagerUsers();
            this.Hide();
            frm.Show();
        }

        private void lblSupplier_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmTransactionIN frm = new frmTransactionIN();
            this.Hide();
            frm.Show();
        }

        private void lblCategory_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmManageCategory frm = new frmManageCategory();
            this.Hide();
            frm.Show();
        }

        private void label11_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void lblIN_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmTransactionIN frm = new frmTransactionIN();
            this.Hide();
            frm.Show();
        }
    }
}

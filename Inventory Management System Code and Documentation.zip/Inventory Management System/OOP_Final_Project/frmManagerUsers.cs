﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP_Final_Project
{
    public partial class frmManagerUsers : Form
    {
        public frmManagerUsers()
        {
            InitializeComponent();
            dgvUsers.DataSource = User.Display();
        }

        void ClearTB()
        {
            txtUname.Text = "USER NAME";
            txtFullName.Text = "USER FULL NAME ";
            txtPwd.Text = "PASSWORD";
            txtPhone.Text = "PHONE No.";
        }

        private void lblDetails_Click(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            User user = new User();
            user.Uname = txtUname.Text;
            user.UfullName = txtFullName.Text;
            user.UPassword = txtPwd.Text;
            user.UPhoneNo = txtPhone.Text;
            try
            {
                string sql = $"INSERT INTO tblUser Values ('{user.Uname}','{user.UfullName}','{ user.UPassword}','{user.UPhoneNo}')";
                DB.SaveData(sql);
                MessageBox.Show("Data Saved To Database");
                btnShow_Click(sender, e);
                ClearTB();
            }
            catch (Exception)
            {
                MessageBox.Show("Data Not Saved to Database");
                
            }
            
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            
            dgvUsers.DataSource = User.Display();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            User user = new User();
            user.Uname = txtUname.Text;
            user.UfullName = txtFullName.Text;
            user.UPassword = txtPwd.Text;
            user.UPhoneNo = txtPhone.Text;
            try
            {
                string sql = $@"UPDATE tblUser
                             SET [Uname] = '{user.Uname}',
                                 [UfullName] = '{user.UfullName}',
                                 [Upassword] = '{user.UPassword}',
                                 [Uphone]   = '{ user.UPhoneNo}' where [Uphone] = '{ user.UPhoneNo}'
                             ";
                DB.SaveData(sql);
                MessageBox.Show("Data Updated in Database");
                btnShow_Click(sender, e);
                ClearTB();

            }
            catch (Exception)
            {
                MessageBox.Show("Data Not Updated");
                throw;
              
            }


        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            
        }

        private void dgvUsers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
               
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void lblSelect_Click(object sender, EventArgs e)
        {
            
         

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            User user = new User();
            user.UPhoneNo = txtPhone.Text;
            try
            {
                string sql = $@"Delete tblUser
                             where [Uphone] = '{ user.UPhoneNo}'
                             ";
                DB.SaveData(sql);
                MessageBox.Show("Data Deleted From Database");
                btnShow_Click(sender, e);
                ClearTB();

            }
            catch (Exception)
            {
                MessageBox.Show("Data Not Deleted");
                throw;

            }

        }

        private void dgvUsers_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (dgvUsers.SelectedRows.Count > 0)
            {
                txtUname.Text = dgvUsers.SelectedRows[0].Cells[0].Value.ToString();
                txtFullName.Text = dgvUsers.SelectedRows[0].Cells[1].Value.ToString();
                txtPwd.Text = dgvUsers.SelectedRows[0].Cells[2].Value.ToString();
                txtPhone.Text = dgvUsers.SelectedRows[0].Cells[3].Value.ToString();
            }

           
        }

        private void txtUname_OnValueChanged(object sender, EventArgs e)
        {

        }
    }
}

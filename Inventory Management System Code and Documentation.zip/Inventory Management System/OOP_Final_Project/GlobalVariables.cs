﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Final_Project
{
    class GlobalVariables
    {
        public static User loggedInuser = new User();
        public static int GBillID { get; set; } = 0;
    }
}

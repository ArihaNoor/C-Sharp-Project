﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OOP_Final_Project
{
    public class SupplierReciept
    {
        public int Billid { get; set; }
        public int ProductID { get; set; }
        public string ProdName { get; set; }
        public float UnitPrice { get; set; }
        public int Unit { get; set; }
        
    }
}
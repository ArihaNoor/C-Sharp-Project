﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Final_Project
{
    class User
    {
        public string  Uname { get; set; }
        public string  UfullName { get; set; }
        public string UPassword { get; set; }
        public string UPhoneNo { get; set; }
        public string Role { get; set; }

        internal Product Product
        {
            get => default(Product);
            set
            {
            }
        }

        internal Customer Customer
        {
            get => default(Customer);
            set
            {
            }
        }

        internal Supplier Supplier
        {
            get => default(Supplier);
            set
            {
            }
        }

        public static DataTable Display()
        {
            string sql = "Select * From tblUser";
            DataTable dt = DB.getDatabyQuery(sql);
            return dt;
        }


    }


}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OOP_Final_Project
{
    public class Category
    {
        public int CatID { get; set; }
        public string CatName { get; set; }
    }
}
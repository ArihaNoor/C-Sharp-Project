﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Final_Project
{
    class Supplier
    {
        public int SID { get; set; }
        public string Sname { get; set; }
        public string SPhoneNo { get; set; }

    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP_Final_Project
{
    public partial class frmCustomerBill : Form
    {
        public frmCustomerBill()
        {
            InitializeComponent();
        }

        frmTransactionOUT frm = new frmTransactionOUT();
        private void frmCustomerBill_Load(object sender, EventArgs e)
        {
           
            string sql = $@"Select a.BillID,ProductID,ProductName,UnitPrice,Unit,a.TotalPrice,c.CustName 
                            From tblCustBillDetail a, tblCustBill b,tblCustomer c
                            Where a.BillID = b.BillID AND b.CustID = c.CustID AND a.BillID = {GlobalVariables.GBillID}";
            DataTable dt = DB.getDatabyQuery(sql);
            txtBillID.Text = dt.Rows[0]["BillID"].ToString();
            txtCustName.Text = dt.Rows[0]["CustName"].ToString();
            txtTotalBill.Text = dt.Rows[0]["TotalPrice"].ToString();
            dgvBill.DataSource = dt;
        }

        private void dgvBill_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}

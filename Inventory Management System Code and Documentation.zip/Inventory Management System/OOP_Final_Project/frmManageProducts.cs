﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP_Final_Project
{
    public partial class frmManageProducts : Form
    {
        public frmManageProducts()
        {
            InitializeComponent();
            dgvProducts.DataSource = Product.Display();
            LoadList();


        }
        void ClearTB()
        {

            txtPname.Text = "PRODUCT NAME";
            txtDesc.Text = "PRODUCT DESCRIPTION";
            txtPrice.Text = "PRODUCT PRICE";
            cmbCatName.Text = "PRODUCT CATEGORY";
        }
        void LoadList()
        {
            string sql = "Select CatID,CatName From tblCategory";
            DataTable dt = DB.getDatabyQuery(sql);
            cmbCatName.DataSource = dt;
            cmbCatName.DisplayMember = "CatName";
            cmbCatName.ValueMember = "CatID";

        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            Product pr = new Product();
            pr.ProdName = txtPname.Text;
            pr.ProdDesc = txtDesc.Text;
            pr.ProdPrice = float.Parse(txtPrice.Text);
            pr.ProdUnit = txtProdUnit.Text;
            try
            {
                string sql = $@"INSERT INTO tblProduct([ProdName],[ProdDesc],[ProdPrice],[CatID],[ProdUnit]) 
                                Values('{pr.ProdName}','{pr.ProdDesc}',{pr.ProdPrice},'{cmbCatName.SelectedValue.ToString()}','{pr.ProdUnit}')";
                DB.SaveData(sql);
                MessageBox.Show("Data Saved to Database");
                btnShow_Click_1(sender, e);
                ClearTB();
            }
            catch (Exception)
            {
                MessageBox.Show("Data NOT Saved to Database");
            }
        }

        private void btnUpdate_Click_1(object sender, EventArgs e)
        {
            if (dgvProducts.SelectedRows.Count > 0)
            {
                Product pr = new Product();
                pr.ProdID = int.Parse(txtPID.Text);
                pr.ProdName = txtPname.Text;
                pr.ProdDesc = txtDesc.Text;
                pr.ProdPrice = float.Parse(txtPrice.Text);
                pr.ProdUnit = txtProdUnit.Text;
                try
                {
                    string sql = $@"UPDATE tblProduct
                             SET [ProdName] = '{pr.ProdName}',[ProdDesc] = '{pr.ProdDesc}',[ProdPrice] = {pr.ProdPrice},[CatID] = '{cmbCatName.SelectedValue.ToString()}',
                                   [ProdUnit] = '{pr.ProdUnit}' where [ProductID] = {pr.ProdID}";
                    DB.SaveData(sql);
                    MessageBox.Show("Data Updated in Database");
                    btnShow_Click_1(sender, e);
                    ClearTB();

                }
                catch (Exception)
                {
                    MessageBox.Show("Data Not Updated");
                    throw;

                }
            }
            else
            {
                MessageBox.Show("Select Rows to Update");
            }
        }

        private void btnDelete_Click_1(object sender, EventArgs e)
        {
            Product pr = new Product();
            pr.ProdID = int.Parse(txtPID.Text);
            try
            {
                string sql = $@"Delete tblProduct
                             where [ProductID] = {pr.ProdID}
                             ";
                DB.SaveData(sql);
                MessageBox.Show("Data Deleted From Database");
                btnShow_Click_1(sender, e);
                ClearTB();

            }
            catch (Exception)
            {
                MessageBox.Show("Data Not Deleted");
                throw;

            }
        }

        private void btnSearch_Click_1(object sender, EventArgs e)
        {
            if (rdbName.Checked == true)
            {
                string sql = $@"SELECT [ProductID],[ProdName],[ProdDesc],[ProdPrice],b.catname
                                FROM [tblProduct] a, tblCategory b
                                where a.catid=b.catid AND ProdName = '{txtSname.Text}'";
                DataTable dt = DB.getDatabyQuery(sql);
                dgvProducts.DataSource = dt;
                dgvProducts.Refresh();
            }
            else if (rdbID.Checked == true)
            {
                string sql = $@"SELECT [ProductID],[ProdName],[ProdDesc],[ProdPrice],b.catname
                                FROM [tblProduct] a, tblCategory b
                                where a.catid=b.catid AND ProductID = {txtSname.Text}";
                DataTable dt = DB.getDatabyQuery(sql);
                dgvProducts.DataSource = dt;
            }
            else if (rdbCat.Checked == true)
            {
                string sql = $@"SELECT [ProductID],[ProdName],[ProdDesc],[ProdPrice],b.catname
                                FROM [tblProduct] a, tblCategory b
                                where a.catid=b.catid AND CatName = '{txtSname.Text}'";
                DataTable dt = DB.getDatabyQuery(sql);
                dgvProducts.DataSource = dt;
            }
            else
            {
                dgvProducts.DataSource = Product.Display();
            }
        }

        private void btnHome_Click_1(object sender, EventArgs e)
        {
            frmHome frm = new frmHome();
            this.Hide();
            frm.Show();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            frmManageCategory frm = new frmManageCategory();
            frm.Show();
        }

        private void dgvProducts_CellMouseDoubleClick_1(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (dgvProducts.SelectedRows.Count > 0)
            {
                txtPID.Text = dgvProducts.SelectedRows[0].Cells[0].Value.ToString();
                txtPname.Text = dgvProducts.SelectedRows[0].Cells[1].Value.ToString();
                txtDesc.Text = dgvProducts.SelectedRows[0].Cells[2].Value.ToString();
                txtPrice.Text = dgvProducts.SelectedRows[0].Cells[3].Value.ToString();
                cmbCatName.SelectedText = dgvProducts.SelectedRows[0].Cells[4].Value.ToString();
                txtProdUnit.Text = dgvProducts.SelectedRows[0].Cells[5].Value.ToString();

            }
        }

        private void label2_Click_1(object sender, EventArgs e)
        {
            Application.Exit();


        }

        private void btnShow_Click_1(object sender, EventArgs e)
        {
            dgvProducts.DataSource = Product.Display();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP_Final_Project
{
    public partial class frmTransactionOUT : Form
    {
        public frmTransactionOUT()
        {
            InitializeComponent();
            LoadCustomerList();
            LoadProductList();
            

        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            frmHome frm = new frmHome();
            this.Hide();
            frm.Show();
            
        }

        void LoadCustomerList()
        {
            string sql = "Select CustID,CustName,CustPhone From tblCustomer";
            DataTable dt = DB.getDatabyQuery(sql);
            cmbCustList.DataSource = dt;
            cmbCustList.DisplayMember = "CustName";
            cmbCustList.ValueMember = "CustID";

        }
        void LoadProductList()
        {
            string sql = "Select ProductID,ProdName From tblProduct";
            DataTable dt = DB.getDatabyQuery(sql);
            cmbProdList.DataSource = dt;
            cmbProdList.DisplayMember = "ProdName";
            cmbProdList.ValueMember = "ProductID";
            

        }
        void LoadProduct(int ID)
        {
            string sql = $"Select ProductID,ProdName,ProdDesc,ProdPrice,CatID,ProdUnit From tblProduct where productid={ID} ";
            DataTable dt = DB.getDatabyQuery(sql);
            txtUnit.Text = dt.Rows[0]["ProdUnit"].ToString();
            txtUprice.Text = dt.Rows[0]["prodPrice"].ToString();

        }
       

        private void label11_Click(object sender, EventArgs e)
        {
            frmHome frm = new frmHome();
            this.Hide();
            frm.Show();
        }

        private void cmbCustList_Leave(object sender, EventArgs e)
        {
            if (cmbCustList.SelectedIndex >= 0)
            {
                txtCustID.Text = cmbCustList.SelectedValue.ToString();
                txtCustName.Text = cmbCustList.Text;
            }
            else
            {
                txtCustID.Text = "CUSTOMER ID";
                txtCustName.Text = "CUSTOMER NAME";
            }
        }

        

        private void cmbProdList_Leave(object sender, EventArgs e)
        {
            if (cmbProdList.SelectedIndex >= 0)
            {
                LoadProduct(int.Parse(cmbProdList.SelectedValue.ToString()));
            }
           
        }

       

        private void txtPrice_Leave(object sender, EventArgs e)
        {
            float price = float.Parse(txtUprice.Text);
            int Quantity = int.Parse(txtQTY.Text.ToString());
            
        }

        float calPrice()
        {
            float price;
            int qty = int.Parse(txtQTY.Text.ToString());
            float uprice = float.Parse(txtUprice.Text);
            price = qty * uprice;
            return price;
          
        }
        DataTable dt = new DataTable();

        void calTotal()
        {
            float sum = 0;
            if (dgvOrder.Rows.Count > 0)
            {
                foreach(DataGridViewRow R in dgvOrder.Rows)
                {
                    sum += float.Parse(R.Cells["TotalPrice"].Value.ToString());
                }

            }
            txtGtotal.Text = sum.ToString();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dgvOrder.Rows.Add(dgvOrder.Rows.Count+1,cmbProdList.SelectedValue.ToString(),cmbCustList.SelectedValue.ToString(),cmbProdList.Text,txtUprice.Text,txtUnit.Text,txtQTY.Text,calPrice());
            dgvOrder.Refresh();
            calTotal();
           
            

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dgvOrder.SelectedRows.Count > 0)
            {
                dgvOrder.Rows.RemoveAt(dgvOrder.SelectedRows[0].Index);
            
                dgvOrder.Refresh();
                calTotal();
            }
            else
            {
                MessageBox.Show("Select Rows to delete");
            }
           

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            
        }
        
       
        private void btnSave_Click(object sender, EventArgs e)
        {
            
            if(string.IsNullOrEmpty(txtCustID.Text) || dgvOrder.Rows.Count < 1)
            {
                MessageBox.Show(this, "Please select customer first, or no items are added.");
                return;
            }

            string sqli = $@"INSERT INTO [dbo].[tblCustBill]([CustID],[TotalPrice],[EnterdBy])
                             VALUES({txtCustID.Text},{txtGtotal.Text},'{GlobalVariables.loggedInuser.Uname}')
                             ; select SCOPE_IDENTITY() as billid";
            DataTable dt = DB.getDatabyQuery(sqli);
            if (dt.Rows.Count > 0)
            {
                int nBillId = int.Parse(dt.Rows[0]["billid"].ToString());
                
                foreach (DataGridViewRow row in dgvOrder.Rows)
                {

                    int pid = int.Parse(row.Cells["ProductID"].Value.ToString());
                    float price = float.Parse(row.Cells["UnitPrice"].Value.ToString());
                    float tPrice = float.Parse(row.Cells["TotalPrice"].Value.ToString());
                    string sqlord = $@"INSERT INTO [dbo].[tblCustBillDetail]([BillID],[ProductID],[ProductName],[UnitPrice],[Unit],[TotalPrice])
                                       VALUES({nBillId},{pid},'{row.Cells["ProductName"].Value.ToString()}',{price},'{row.Cells["ProductUnit"].Value.ToString()}',{tPrice})";
                    DB.getDatabyQuery(sqlord);
                    
                }
                MessageBox.Show("Bill Created");
                GlobalVariables.GBillID = nBillId;
                frmCustomerBill frm = new frmCustomerBill();
                frm.Show();
            }
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void frmTransactionOUT_Load(object sender, EventArgs e)
        {

        }

        private void cmbProdList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            frmHome frm = new frmHome();
            this.Hide();
            frm.Show();
        }
    }
}
